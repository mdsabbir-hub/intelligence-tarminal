# ForthPoint Data

Apple Numbers → JSON data pipeline that powers the ForthPoint Terminal app on Vercel.

## How it works

```
source/database.numbers  (you edit this, directly in the Numbers app)
        │  upload to GitHub
        ▼
GitHub Action runs (on push, daily 06:00 UTC, or manual)
        │  npm run build:data
        ▼
scripts/numbers-parser.py  → reads every sheet/table natively → tmp-data/raw.json
scripts/generate-json.js   → splits into /data/<dataset>/...
scripts/validate-data.js   → fails the build if data looks broken
        │  commits /data if it changed
        ▼
Vercel detects the new commit → redeploys automatically
```

`.numbers` is read directly via the `numbers-parser` Python library - no
conversion to Excel, no LibreOffice, no data loss. A Numbers sheet can hold
multiple tables (Apple's "canvas" layout); each table becomes its own
dataset, named `SheetName` if it's the only table on that sheet, or
`SheetName - TableName` if there are several.

## Folder structure

```
forthpoint-data/
├── source/
│   └── database.numbers      # the master Numbers file - edit this to update data
├── data/                      # GENERATED - do not edit by hand
│   ├── manifest.json          # list of every dataset + metadata
│   └── <dataset-slug>/
│       ├── all.json           # full dataset, all rows/fields
│       └── records/
│           └── <key>.json     # one file per row (only if a key column was found)
├── scripts/
│   ├── numbers-parser.py      # Numbers file → tmp-data/raw.json (Python)
│   ├── generate-json.js       # raw.json → final /data structure
│   └── validate-data.js       # sanity checks before commit/deploy
├── src/
│   └── lib/data.ts            # the ONLY file the frontend should import data from
├── .github/workflows/
│   └── update-data.yml        # the automation described above
├── requirements.txt           # Python deps (numbers-parser)
├── public/                    # static assets for the app
├── package.json
└── .gitignore
```

## Daily update workflow (from your phone)

1. Edit `source/database.numbers` directly in the Numbers app.
2. Upload the updated file to this repo, replacing `source/database.numbers`
   (via github.com in Safari, or the GitHub app).
3. That's it. The Action detects the change, regenerates `/data`, commits it,
   and Vercel redeploys automatically. Also runs on its own every day at
   06:00 UTC as a safety net.
4. Check progress under the repo's **Actions** tab - the first run, or after
   any big structural change to the file, is worth checking manually
   (**Actions → Update ForthPoint Data → Run workflow**) to confirm the
   parser read everything correctly.

## Local / CI commands

```bash
pip install -r requirements.txt
npm install
npm run parse      # source/database.numbers -> tmp-data/raw.json
npm run generate   # tmp-data/raw.json -> /data
npm run validate   # sanity-check /data
npm run build:data # parse + generate + validate, in order
```

Note: `numbers-parser` only runs on macOS/Linux with network access to
install (fine on GitHub Actions or a Mac; this can't be tested inside a
sandboxed, offline environment).

## Using the data in the app

Always go through `src/lib/data.ts` - never read `/data` JSON directly from
pages/components. This keeps a single migration point for later.

```ts
import { getManifest, getDataset, getRecord, getPaginatedDataset } from "@/lib/data";

const manifest = getManifest();               // what datasets exist
const companies = getDataset("companies");     // full list
const one = getRecord("companies", "AAPL");    // single record, fast lookup
const page = getPaginatedDataset("prices", 1, 50); // paginated table view
```

## Adding a primary key so a table gets per-record files

`generate-json.js` looks for a column named one of:
`id`, `symbol`, `ticker`, `code` (case-insensitive-ish). If your table has
one of these, each row also gets its own file under `records/`, so the app
can fetch a single company/price without loading the whole table - this is
what keeps things fast at 10,000+ companies.

## Scaling notes (10k+ companies, 20 years of financials, daily prices)

- Per-record JSON files mean a page for one company only loads that
  company's file, not the whole dataset.
- Use `getPaginatedDataset()` for any large list/table view.
- Pair with Next.js **ISR** (`revalidate: 3600` or similar) so pages are
  served statically and only rebuilt periodically, not on every request.
- If a single table (e.g. daily prices across 20 years) grows past a few
  hundred MB, split it further by year in `generate-json.js` before that
  becomes a problem - the manifest-driven design makes this a script change,
  not a frontend rewrite.
- When git/JSON stops being enough, swap the internals of `src/lib/data.ts`
  for SQL queries (Postgres/Supabase/Neon) - nothing else in the app changes.

## Vercel notes

- Connect this GitHub repo to a Vercel project once; every push to `main`
  redeploys automatically - no extra setup needed.
- Vercel only rebuilds on new commits, so the bot commit from the Action is
  what triggers deployment (not the workflow run itself).
- To avoid redeploying on non-data commits (e.g. docs-only changes), you can
  later add an `ignoreCommand` in `vercel.json` that checks if `data/` or
  `src/` changed.
